package com.globelabs.api;

public abstract class PostRequestHandler {
	public abstract void postProcess(String string);
}
