rest-java
=========

Globe OAuth and RESTful service wrapper in Java
