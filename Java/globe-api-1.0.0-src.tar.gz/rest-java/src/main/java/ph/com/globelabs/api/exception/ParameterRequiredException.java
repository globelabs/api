package ph.com.globelabs.api.exception;

public class ParameterRequiredException extends Exception {

    public ParameterRequiredException(String exceptionMessage) {
        super(exceptionMessage);
    }

    private static final long serialVersionUID = 6092716772259056591L;

}
